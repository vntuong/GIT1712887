﻿#include <fcntl.h> 
#include <io.h>   
#include <stdio.h>
#include <conio.h>
#include <string>
struct SinhVien
{
	wchar_t* MSSV;
	wchar_t* HoTen;
	wchar_t* Khoa;
	wchar_t* KhoaHoc;
	wchar_t* NgaySinh;
	wchar_t* Anh;
	wchar_t* Email;
	wchar_t* MoTa;
	wchar_t* SoThich;
};
typedef struct SinhVien SINHVIEN;

void DocFileSinhVienCSV(FILE* DuLieu, SINHVIEN* &sv, int &i)
{
	i = 0;
	while (!feof(DuLieu))
	{
		wchar_t* buf = (wchar_t*)malloc(150 * sizeof(wchar_t));
		fgetws(buf, 150, DuLieu);
		(*(sv + i)).MSSV = wcstok(buf, L",");
		(*(sv + i)).HoTen = wcstok(NULL, L",");
		(*(sv + i)).Khoa = wcstok(NULL, L",");
		(*(sv + i)).KhoaHoc = wcstok(NULL, L",");
		(*(sv + i)).NgaySinh = wcstok(NULL, L",");
		(*(sv + i)).Anh = wcstok(NULL, L",");
		(*(sv + i)).Email = wcstok(NULL, L",");
		(*(sv + i)).MoTa = wcstok(NULL, L",");
		(*(sv + i)).SoThich = wcstok(NULL, L"\n");
		i++;
	}
}
void XuatSV(SINHVIEN* sv, int line)
{
	for (int i = 0; i < line; i++)
	{
		wprintf(L"%ls, %ls, %ls, %ls, %ls, %ls, %ls, %ls, %ls\n", sv[i].MSSV, sv[i].HoTen, sv[i].Khoa, sv[i].KhoaHoc, sv[i].NgaySinh, sv[i].Anh, sv[i].Email, sv[i].MoTa, sv[i].SoThich);
	}
}

int ViTriChuoiConTrongChuoiCha(wchar_t* s, wchar_t* s1)
{
	int i, j;
	int l = wcslen(s), l1 = wcslen(s1);
	if (l1 > l)
	{
		return -1;
	}
	else
	{
		if (l1 == l)
		{
			for (i = 0; i < l; i++)
			{
				if (s[i] != s1[i])
					return -1;
			}
			return 0;
		}
		else
		{
			for (i = 0; i < l - l1; i++)
			{
				int dem = 0;
				for (j = 0; j < l1; j++)
				{
					if (s[i + j] == s1[j])
						dem++;
					else
						break;
				}
				if (dem == l1)
					return i;
			}
			return -1;
		}
	}
}
wchar_t* ThayTheChuoi(wchar_t* s, wchar_t* s1, wchar_t* s2)
{
	int i, j;
	int l = wcslen(s), l1 = wcslen(s1), l2 = wcslen(s2);
	int pos = ViTriChuoiConTrongChuoiCha(s, s1);
	wchar_t* arrTruoc = (wchar_t*)malloc(pos * sizeof(wchar_t));
	wchar_t* arrSau = (wchar_t*)malloc((l - pos - l1) * sizeof(wchar_t));
	if (pos == -1)
	{
		return s;
	}
	else
	{
		for (i = 0; i < pos; i++)
		{
			arrTruoc[i] = s[i];
		}
		arrTruoc[i] = '\0';
		for (j = 0; j < l - pos - l1; j++)
		{
			arrSau[j] = s[j + pos + l1];
		}
		arrSau[j] = '\0';
	}
	wchar_t* arrLast = (wchar_t*)malloc(150 * sizeof(wchar_t));
	wcscpy(arrLast, arrTruoc);
	wcscat(wcscat(arrLast, s2), arrSau);
	return arrLast;
}
void XuatHTML(SINHVIEN sv)
{
	wchar_t strMSSV[] = L"MaSoSinhVien";
	wchar_t strHoTen[] = L"HoVaTen";
	wchar_t strKhoa[] = L"KhoaCuaBan";
	wchar_t strKhoaHoc[] = L"KhoaHocCuaBan";
	wchar_t strNgaySinh[] = L"NgaySinhCuaBan";
	wchar_t strHinhAnh[] = L"LinkHinhAnh";
	wchar_t strEmail[] = L"EmailCuaBan";
	wchar_t strMoTa[] = L"MoTaBanThan";
	wchar_t strSoThich[] = L"SoThichCuaBan";
	wchar_t* filename = (wchar_t*)malloc(30 * sizeof(wchar_t));
	wcscpy(filename, L"Website\\");
	wcscat(filename, sv.MSSV);
	wcscat(filename, L".htm");
	FILE* fb = _wfopen(filename, L"wt, ccs=UTF-8");
	FILE* MaNguon = _wfopen(L"MaNguonHTML.txt", L"rt, ccs=UTF-8");
	while (!feof(MaNguon))
	{
		wchar_t* buf = (wchar_t*)malloc(200 * sizeof(wchar_t));
		fgetws(buf, 200, MaNguon);
		int a = ViTriChuoiConTrongChuoiCha(buf, strHoTen);
		int b = ViTriChuoiConTrongChuoiCha(buf, strMSSV);
		int c = ViTriChuoiConTrongChuoiCha(buf, strKhoa);
		int d = ViTriChuoiConTrongChuoiCha(buf, strKhoaHoc);
		int e = ViTriChuoiConTrongChuoiCha(buf, strNgaySinh);
		int f = ViTriChuoiConTrongChuoiCha(buf, strHinhAnh);
		int g = ViTriChuoiConTrongChuoiCha(buf, strEmail);
		int h = ViTriChuoiConTrongChuoiCha(buf, strMoTa);
		int k = ViTriChuoiConTrongChuoiCha(buf, strSoThich);
		
		if (a != -1)
			fputws(ThayTheChuoi(buf, strHoTen, sv.HoTen), fb);
		if (b != -1)
			fputws(ThayTheChuoi(buf, strMSSV, sv.MSSV), fb);
		if (c != -1)
			fputws(ThayTheChuoi(buf, strKhoa, sv.Khoa), fb);
		if (d != -1)
			fputws(ThayTheChuoi(buf, strKhoaHoc, sv.KhoaHoc), fb);
		if (e != -1)
			fputws(ThayTheChuoi(buf, strNgaySinh, sv.NgaySinh), fb);
		if (f != -1)
			fputws(ThayTheChuoi(buf, strHinhAnh, sv.Anh), fb);
		if (g != -1)
			fputws(ThayTheChuoi(buf, strEmail, sv.Email), fb);
		if (h != -1)
			fputws(ThayTheChuoi(buf, strMoTa, sv.MoTa), fb);
		if (k != -1)
			fputws(ThayTheChuoi(buf, strSoThich, sv.SoThich), fb);
		
		if (a == -1 && b ==-1 && c ==-1 && d ==-1 && e ==-1 && f ==-1 && g ==-1 && h ==-1 && k == -1)
		{
			fputws(buf, fb);
		}
	}
	fclose(fb);
	fclose(MaNguon);
}


void main()
{
	_setmode(_fileno(stdout), _O_U8TEXT);
	_setmode(_fileno(stdin), _O_U8TEXT);
	SINHVIEN* sv = (SINHVIEN*)malloc(10 * sizeof(SINHVIEN));
	FILE* DuLieu = _wfopen(L"DuLieuSinhVien.csv", L"rt, ccs = UTF-8");
	int line;
	DocFileSinhVienCSV(DuLieu, sv, line);
	XuatSV(sv, line);
	for (int i = 0; i < line; i++)
	{
		XuatHTML(sv[i]);
	}
	free(sv);
	fclose(DuLieu);
}